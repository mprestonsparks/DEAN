#!/bin/bash

# DEAN Installation Script

set -e

echo "DEAN Orchestration System Installer"
echo "==================================="
echo ""

# Check requirements
echo "Checking system requirements..."

# Check Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker 20.10+"
    exit 1
fi

# Check Docker Compose
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose 2.0+"
    exit 1
fi

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.10+"
    exit 1
fi

echo "✅ All requirements satisfied"
echo ""

# Create directories
echo "Creating directories..."
mkdir -p logs
mkdir -p data
mkdir -p certs

# Copy environment template
if [ ! -f .env ]; then
    echo "Creating environment configuration..."
    cp configs/templates/.env.template .env
    echo "⚠️  Please edit .env file with your configuration"
    echo ""
fi

# Build Docker images
echo "Building Docker images..."
docker-compose -f docker-compose.dev.yml build

# Initialize database
echo "Initializing database..."
docker-compose -f docker-compose.dev.yml up -d postgres-dev
sleep 5

# Run migrations
echo "Running database migrations..."
docker-compose -f docker-compose.dev.yml run --rm orchestrator python scripts/utilities/db_migrate.py up

echo ""
echo "✅ Installation complete!"
echo ""
echo "Next steps:"
echo "1. Edit .env file with your configuration"
echo "2. Run ./scripts/first_run.sh to create admin user"
echo "3. Start services with: docker-compose -f docker-compose.dev.yml up -d"
echo ""
