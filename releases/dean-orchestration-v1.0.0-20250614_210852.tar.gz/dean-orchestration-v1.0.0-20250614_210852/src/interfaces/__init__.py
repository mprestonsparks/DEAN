"""User interfaces for DEAN orchestration.

Provides:
- Command-line interface (CLI)
- Web dashboard
- API gateway
"""