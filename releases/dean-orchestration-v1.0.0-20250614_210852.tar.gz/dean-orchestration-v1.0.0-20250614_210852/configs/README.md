# DEAN Configuration

This directory contains configuration files for the DEAN orchestration system.

## Directory Structure

- `orchestration/` - Core orchestration configurations
  - Default settings
  - Single-machine configurations
  - Distributed deployment configurations

- `services/` - External service connection configurations
  - IndexAgent connection settings
  - Airflow connection settings
  - Infrastructure service settings

## Purpose

Configuration files in this directory:

1. **Define Service Endpoints**: Connection details for external services
2. **Control Behavior**: Orchestration parameters and settings
3. **Environment Adaptation**: Different configurations for various deployment modes
4. **Security Settings**: Authentication and authorization configurations

## Configuration Management

- YAML format for human readability
- Environment variable override support
- Validation on startup
- Sensitive values excluded (use environment variables)
- Clear documentation of all parameters