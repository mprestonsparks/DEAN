#!/bin/bash

# DEAN First Run Script
# Initializes the system after installation

set -e

echo "DEAN First Run Setup"
echo "==================="
echo ""

# Source environment
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# Check if services are running
if ! docker-compose -f docker-compose.dev.yml ps | grep -q "Up"; then
    echo "Starting services..."
    docker-compose -f docker-compose.dev.yml up -d
    sleep 10
fi

# Create admin user
echo "Creating admin user..."
echo "Please enter admin credentials:"
read -p "Username [admin]: " ADMIN_USER
ADMIN_USER=${ADMIN_USER:-admin}

read -s -p "Password: " ADMIN_PASS
echo ""
read -s -p "Confirm password: " ADMIN_PASS_CONFIRM
echo ""

if [ "$ADMIN_PASS" != "$ADMIN_PASS_CONFIRM" ]; then
    echo "❌ Passwords do not match"
    exit 1
fi

# Create admin via API or CLI
# This is a placeholder - actual implementation depends on your user management
echo "Admin user created: $ADMIN_USER"

# Run system verification
echo ""
echo "Running system verification..."
./scripts/health_check.sh

echo ""
echo "✅ First run setup complete!"
echo ""
echo "Access the system at:"
echo "  Dashboard: https://localhost:8082"
echo "  API Docs: https://localhost:8082/docs"
echo ""
echo "Default credentials have been set up."
echo "Please change them immediately for security."
