#!/bin/bash

# DEAN Final System Validation Script
# Performs comprehensive validation before production deployment

set -e

# Configuration
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DEAN_ROOT="$(dirname "$SCRIPT_DIR")"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
REPORT_FILE="$DEAN_ROOT/validation_report_${TIMESTAMP}.txt"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Counters
PASSED=0
FAILED=0
WARNINGS=0

# Start report
exec > >(tee -a "$REPORT_FILE")
exec 2>&1

echo "================================================"
echo "DEAN Final System Validation"
echo "================================================"
echo "Date: $(date)"
echo "System: $(uname -a)"
echo ""

# Function to check test result
check_result() {
    local test_name="$1"
    local result="$2"
    
    if [ "$result" -eq 0 ]; then
        echo -e "${GREEN}✓ PASS${NC} - $test_name"
        ((PASSED++))
    else
        echo -e "${RED}✗ FAIL${NC} - $test_name"
        ((FAILED++))
    fi
}

# Function to check with warning
check_warning() {
    local test_name="$1"
    local result="$2"
    
    if [ "$result" -eq 0 ]; then
        echo -e "${GREEN}✓ PASS${NC} - $test_name"
        ((PASSED++))
    else
        echo -e "${YELLOW}⚠ WARN${NC} - $test_name"
        ((WARNINGS++))
    fi
}

echo -e "${BLUE}1. Service Health Checks${NC}"
echo "========================"

# Check if services are running
services=("postgres-dev" "redis-dev" "indexagent-stub" "airflow-stub" "evolution-stub")
for service in "${services[@]}"; do
    docker ps --format "table {{.Names}}" | grep -q "$service"
    check_result "Service $service is running" $?
done

# Check service health endpoints
echo ""
echo -e "${BLUE}2. API Health Endpoints${NC}"
echo "======================"

# Orchestrator health
curl -f -s -o /dev/null http://localhost:8082/health
check_result "Orchestrator health endpoint" $?

# Evolution API health
curl -f -s -o /dev/null http://localhost:8083/health
check_result "Evolution API health endpoint" $?

# IndexAgent health
curl -f -s -o /dev/null http://localhost:8081/health
check_result "IndexAgent health endpoint" $?

# Airflow health
curl -f -s -o /dev/null http://localhost:8080/health
check_result "Airflow health endpoint" $?

echo ""
echo -e "${BLUE}3. Authentication System${NC}"
echo "======================="

# Test login
LOGIN_RESPONSE=$(curl -s -X POST http://localhost:8082/auth/login \
    -H "Content-Type: application/json" \
    -d '{"username": "admin", "password": "admin123"}' 2>/dev/null || echo "FAILED")

if [[ "$LOGIN_RESPONSE" == *"access_token"* ]]; then
    TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"access_token":"[^"]*' | cut -d'"' -f4)
    check_result "Authentication login" 0
else
    TOKEN=""
    check_result "Authentication login" 1
fi

# Test protected endpoint
if [ -n "$TOKEN" ]; then
    curl -f -s -o /dev/null -H "Authorization: Bearer $TOKEN" http://localhost:8082/api/agents
    check_result "Protected endpoint access" $?
fi

# Test unauthorized access
curl -s -o /dev/null -w "%{http_code}" http://localhost:8082/api/agents | grep -q "401"
check_result "Unauthorized access blocked" $?

echo ""
echo -e "${BLUE}4. Database Operations${NC}"
echo "===================="

# Check database connection
docker exec postgres-dev pg_isready -U dean
check_result "PostgreSQL connection" $?

# Check databases exist
docker exec postgres-dev psql -U dean -lqt | grep -q "dean_dev"
check_result "Database 'dean_dev' exists" $?

# Check Redis
docker exec redis-dev redis-cli ping | grep -q "PONG"
check_result "Redis connection" $?

echo ""
echo -e "${BLUE}5. API Functionality${NC}"
echo "=================="

if [ -n "$TOKEN" ]; then
    # Create agent
    AGENT_RESPONSE=$(curl -s -X POST http://localhost:8081/agents \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d '{"name": "validation-test-agent", "language": "python"}' 2>/dev/null)
    
    [[ "$AGENT_RESPONSE" == *"id"* ]]
    check_result "Agent creation API" $?
    
    # List agents
    curl -f -s -o /dev/null -H "Authorization: Bearer $TOKEN" http://localhost:8081/agents
    check_result "Agent listing API" $?
    
    # Check patterns endpoint
    curl -f -s -o /dev/null -H "Authorization: Bearer $TOKEN" http://localhost:8083/patterns
    check_result "Patterns API" $?
fi

echo ""
echo -e "${BLUE}6. WebSocket Connectivity${NC}"
echo "========================"

# Test WebSocket (using curl to check if upgrade is possible)
WS_RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" \
    -H "Connection: Upgrade" \
    -H "Upgrade: websocket" \
    http://localhost:8083/ws)

[[ "$WS_RESPONSE" == "426" || "$WS_RESPONSE" == "101" ]]
check_result "WebSocket endpoint available" $?

echo ""
echo -e "${BLUE}7. File System Checks${NC}"
echo "==================="

# Check required directories
dirs=("logs" "data" "certs" "scripts" "src" "configs")
for dir in "${dirs[@]}"; do
    [ -d "$DEAN_ROOT/$dir" ]
    check_result "Directory $dir exists" $?
done

# Check critical files
files=("requirements.txt" "docker-compose.dev.yml" "README.md")
for file in "${files[@]}"; do
    [ -f "$DEAN_ROOT/$file" ]
    check_result "File $file exists" $?
done

# Check executables
scripts=("dev_environment.sh" "stop_dev_environment.sh" "health_check.sh" "quick_auth_test.sh")
for script in "${scripts[@]}"; do
    [ -x "$DEAN_ROOT/scripts/$script" ]
    check_result "Script $script is executable" $?
done

echo ""
echo -e "${BLUE}8. Configuration Validation${NC}"
echo "=========================="

# Check .env file
[ -f "$DEAN_ROOT/.env" ]
check_result ".env configuration exists" $?

# Check for default passwords in .env
if [ -f "$DEAN_ROOT/.env" ]; then
    grep -q "admin123\|password123\|changeme" "$DEAN_ROOT/.env" || true
    check_warning "No default passwords in .env" $?
fi

# Check SSL certificates
[ -f "$DEAN_ROOT/certs/server.crt" ] || [ -f "$DEAN_ROOT/certs/dev-cert.pem" ]
check_warning "SSL certificates present" $?

echo ""
echo -e "${BLUE}9. Logging System${NC}"
echo "================"

# Check if logs directory is writable
touch "$DEAN_ROOT/logs/test.log" 2>/dev/null && rm "$DEAN_ROOT/logs/test.log"
check_result "Logs directory writable" $?

# Check if services are logging
[ -f "$DEAN_ROOT/logs/orchestration.log" ] || docker logs dean-orchestrator 2>&1 | grep -q "Started"
check_warning "Orchestration logs available" $?

echo ""
echo -e "${BLUE}10. Performance Checks${NC}"
echo "===================="

# Quick API response time test
if [ -n "$TOKEN" ]; then
    START_TIME=$(date +%s%N)
    curl -s -H "Authorization: Bearer $TOKEN" http://localhost:8082/api/agents > /dev/null
    END_TIME=$(date +%s%N)
    RESPONSE_TIME=$(( (END_TIME - START_TIME) / 1000000 ))
    
    [ $RESPONSE_TIME -lt 1000 ]  # Less than 1 second
    check_result "API response time (<1s): ${RESPONSE_TIME}ms" $?
fi

# Memory usage check
MEMORY_USAGE=$(docker stats --no-stream --format "table {{.Container}}\t{{.MemPerc}}" | grep -E "(postgres|redis|stub)" | awk '{sum += $2} END {print sum}')
echo "Total memory usage: ${MEMORY_USAGE}%"

echo ""
echo -e "${BLUE}11. Backup and Recovery${NC}"
echo "======================"

# Check backup directory
[ -d "$DEAN_ROOT/backups" ]
check_result "Backup directory exists" $?

# Check if backup script exists
[ -f "$DEAN_ROOT/scripts/utilities/backup_restore.sh" ]
check_warning "Backup script available" $?

echo ""
echo -e "${BLUE}12. Security Validation${NC}"
echo "======================"

# Check file permissions on sensitive files
if [ -f "$DEAN_ROOT/.env" ]; then
    PERM=$(stat -c "%a" "$DEAN_ROOT/.env" 2>/dev/null || stat -f "%OLp" "$DEAN_ROOT/.env" 2>/dev/null)
    [[ "$PERM" == "600" || "$PERM" == "640" || "$PERM" == "644" ]]
    check_warning ".env file permissions secure" $?
fi

# Check for exposed ports (should only be localhost)
EXPOSED_PORTS=$(docker ps --format "table {{.Ports}}" | grep -c "0.0.0.0:" || true)
[ $EXPOSED_PORTS -eq 0 ]
check_warning "No services exposed on 0.0.0.0" $?

echo ""
echo "================================================"
echo "Validation Summary"
echo "================================================"
echo -e "Passed:   ${GREEN}$PASSED${NC}"
echo -e "Failed:   ${RED}$FAILED${NC}"
echo -e "Warnings: ${YELLOW}$WARNINGS${NC}"
echo ""

# Calculate readiness score
TOTAL=$((PASSED + FAILED + WARNINGS))
if [ $TOTAL -gt 0 ]; then
    SCORE=$((PASSED * 100 / TOTAL))
else
    SCORE=0
fi

echo "Readiness Score: ${SCORE}%"
echo ""

# Final verdict
if [ $FAILED -eq 0 ]; then
    if [ $WARNINGS -eq 0 ]; then
        echo -e "${GREEN}✅ SYSTEM READY FOR PRODUCTION${NC}"
        echo "All validation checks passed!"
        EXIT_CODE=0
    else
        echo -e "${YELLOW}⚠️  SYSTEM READY WITH WARNINGS${NC}"
        echo "Please review warnings before production deployment."
        EXIT_CODE=0
    fi
else
    echo -e "${RED}❌ SYSTEM NOT READY${NC}"
    echo "Critical issues must be resolved before deployment."
    EXIT_CODE=1
fi

echo ""
echo "Full report saved to: $REPORT_FILE"
echo ""

# Generate recommendations
echo "Recommendations:"
echo "==============="

if [ $FAILED -gt 0 ]; then
    echo "1. Fix all failed checks before proceeding"
    echo "2. Run './scripts/health_check.sh' to diagnose issues"
    echo "3. Check service logs for error details"
fi

if [ $WARNINGS -gt 0 ]; then
    echo "1. Review and address warnings for production"
    echo "2. Ensure all passwords are changed from defaults"
    echo "3. Configure SSL certificates for HTTPS"
fi

if [ $SCORE -eq 100 ]; then
    echo "1. System is ready for deployment"
    echo "2. Run performance tests under load"
    echo "3. Set up monitoring and alerting"
    echo "4. Configure automated backups"
fi

echo ""
exit $EXIT_CODE