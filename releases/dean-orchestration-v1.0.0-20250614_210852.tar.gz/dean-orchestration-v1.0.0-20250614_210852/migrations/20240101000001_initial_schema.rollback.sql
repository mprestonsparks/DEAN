-- Rollback for migration: 20240101000001_initial_schema
-- Created: 2024-01-01T00:00:01

-- Drop schema and all objects
DROP SCHEMA IF EXISTS dean CASCADE;

-- Note: This will remove all data! 
-- Consider backing up before running rollback