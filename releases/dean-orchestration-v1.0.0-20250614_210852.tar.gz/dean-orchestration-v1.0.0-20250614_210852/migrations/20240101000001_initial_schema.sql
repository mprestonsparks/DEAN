-- Migration: 20240101000001_initial_schema
-- Created: 2024-01-01T00:00:01
-- Description: Initial database schema for DEAN orchestration

-- Create schema if not exists
CREATE SCHEMA IF NOT EXISTS dean;

-- Set search path
SET search_path TO dean, public;

-- Evolution trials table
CREATE TABLE IF NOT EXISTS evolution_trials (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trial_id VARCHAR(255) UNIQUE NOT NULL,
    repository VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    configuration JSONB NOT NULL,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    duration_seconds INTEGER,
    results JSONB,
    error_message TEXT,
    created_by VARCHAR(255),
    
    -- Indexes
    CONSTRAINT chk_status CHECK (status IN ('pending', 'running', 'completed', 'failed', 'cancelled'))
);

CREATE INDEX idx_trials_repository ON evolution_trials(repository);
CREATE INDEX idx_trials_status ON evolution_trials(status);
CREATE INDEX idx_trials_started_at ON evolution_trials(started_at DESC);

-- Agents table
CREATE TABLE IF NOT EXISTS agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    repository VARCHAR(255) NOT NULL,
    generation INTEGER DEFAULT 1,
    fitness_score DECIMAL(10, 6),
    configuration JSONB NOT NULL,
    genome JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    trial_id VARCHAR(255) REFERENCES evolution_trials(trial_id) ON DELETE CASCADE,
    parent_id UUID REFERENCES agents(id),
    
    -- Performance metrics
    execution_time_ms INTEGER,
    memory_usage_mb INTEGER,
    success_rate DECIMAL(5, 4)
);

CREATE INDEX idx_agents_repository ON agents(repository);
CREATE INDEX idx_agents_generation ON agents(generation);
CREATE INDEX idx_agents_fitness ON agents(fitness_score DESC);
CREATE INDEX idx_agents_trial ON agents(trial_id);

-- Patterns table
CREATE TABLE IF NOT EXISTS patterns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pattern_id VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    description TEXT,
    frequency INTEGER DEFAULT 1,
    confidence DECIMAL(5, 4) DEFAULT 0.0,
    repositories TEXT[] DEFAULT '{}',
    pattern_data JSONB NOT NULL,
    discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Classification
    category VARCHAR(100),
    tags TEXT[] DEFAULT '{}',
    
    -- Effectiveness metrics
    avg_improvement DECIMAL(10, 6),
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0
);

CREATE INDEX idx_patterns_type ON patterns(type);
CREATE INDEX idx_patterns_confidence ON patterns(confidence DESC);
CREATE INDEX idx_patterns_frequency ON patterns(frequency DESC);
CREATE INDEX idx_patterns_category ON patterns(category);

-- System events table for audit trail
CREATE TABLE IF NOT EXISTS system_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type VARCHAR(100) NOT NULL,
    event_data JSONB NOT NULL,
    severity VARCHAR(20) DEFAULT 'info',
    source VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Context
    user_id VARCHAR(255),
    session_id VARCHAR(255),
    correlation_id VARCHAR(255),
    
    CONSTRAINT chk_severity CHECK (severity IN ('debug', 'info', 'warning', 'error', 'critical'))
);

CREATE INDEX idx_events_type ON system_events(event_type);
CREATE INDEX idx_events_severity ON system_events(severity);
CREATE INDEX idx_events_created_at ON system_events(created_at DESC);
CREATE INDEX idx_events_correlation ON system_events(correlation_id);

-- Service health metrics table
CREATE TABLE IF NOT EXISTS service_health_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_name VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL,
    response_time_ms INTEGER,
    cpu_usage DECIMAL(5, 2),
    memory_usage_mb INTEGER,
    error_count INTEGER DEFAULT 0,
    metadata JSONB,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_health_status CHECK (status IN ('healthy', 'degraded', 'unhealthy', 'unknown'))
);

CREATE INDEX idx_health_service ON service_health_metrics(service_name);
CREATE INDEX idx_health_status ON service_health_metrics(status);
CREATE INDEX idx_health_recorded ON service_health_metrics(recorded_at DESC);

-- Create update timestamp trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply update trigger to agents table
CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON agents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create cleanup function for old data
CREATE OR REPLACE FUNCTION cleanup_old_data(retention_days INTEGER DEFAULT 30)
RETURNS TABLE(
    deleted_events BIGINT,
    deleted_metrics BIGINT
) AS $$
DECLARE
    cutoff_date TIMESTAMP;
BEGIN
    cutoff_date := CURRENT_TIMESTAMP - (retention_days || ' days')::INTERVAL;
    
    -- Delete old events
    WITH deleted AS (
        DELETE FROM system_events
        WHERE created_at < cutoff_date
        AND severity IN ('debug', 'info')
        RETURNING *
    )
    SELECT COUNT(*) INTO deleted_events FROM deleted;
    
    -- Delete old metrics
    WITH deleted AS (
        DELETE FROM service_health_metrics
        WHERE recorded_at < cutoff_date
        RETURNING *
    )
    SELECT COUNT(*) INTO deleted_metrics FROM deleted;
    
    RETURN QUERY SELECT deleted_events, deleted_metrics;
END;
$$ LANGUAGE plpgsql;

-- Grant permissions (adjust as needed)
GRANT USAGE ON SCHEMA dean TO dean_app;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA dean TO dean_app;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA dean TO dean_app;