# DEAN Orchestration

The orchestration layer for the DEAN (Distributed Evolutionary Agent Network) system, providing coordination between IndexAgent, airflow-hub, and infra repositories.

## Overview

DEAN Orchestration serves as the central coordination hub for the distributed DEAN system. It manages cross-service workflows, provides unified interfaces for system interaction, and ensures seamless integration between the three core repositories without requiring direct dependencies.

## Purpose

This repository:
- **Orchestrates** complex workflows across IndexAgent, Airflow, and infrastructure services
- **Provides** unified CLI and web interfaces for system management
- **Abstracts** service communication through clean client interfaces
- **Monitors** system-wide health and performance metrics
- **Manages** deployment and configuration across all services

## Architecture

DEAN Orchestration implements a service-oriented architecture:

```
┌─────────────────────┐     ┌─────────────────────┐     ┌─────────────────────┐
│   IndexAgent API    │     │    Airflow API      │     │ Infrastructure API  │
│    (Port 8081)      │     │    (Port 8080)      │     │   (Port 8090)       │
└──────────┬──────────┘     └──────────┬──────────┘     └──────────┬──────────┘
           │                           │                           │
           └───────────────────────────┴───────────────────────────┘
                                      │
                          ┌───────────┴───────────┐
                          │  DEAN Orchestration   │
                          │   Service Clients     │
                          └───────────┬───────────┘
                                      │
                    ┌─────────────────┴─────────────────┐
                    │                                   │
            ┌───────┴────────┐                ┌────────┴───────┐
            │   CLI Interface │                │ Web Dashboard  │
            └────────────────┘                └────────────────┘
```

## Quick Start

### Prerequisites

- Python 3.10 or higher
- Access to IndexAgent, Airflow, and infrastructure services
- PostgreSQL and Redis instances

### Installation

1. Clone the repository:
```bash
git clone https://github.com/dean-project/DEAN.git
cd DEAN
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
make install-dev
```

4. Configure environment:
```bash
cp .env.example .env
# Edit .env with your service endpoints and credentials
```

5. Run tests to verify setup:
```bash
make test
```

### Basic Usage

Start the orchestration server:
```bash
make serve
```

Use the CLI:
```bash
dean --help
dean evolution start --config configs/orchestration/default.yaml
```

Access the web dashboard:
```
http://localhost:8093
```

## Configuration

DEAN Orchestration uses a layered configuration approach:

1. **Environment Variables**: Primary configuration method (see `.env.example`)
2. **Configuration Files**: YAML files in `configs/` for complex settings
3. **Command Line**: Override specific settings at runtime

Key configuration areas:
- Service endpoints (IndexAgent, Airflow, Infrastructure)
- Database connections
- Deployment modes (single-machine vs distributed)
- Monitoring and alerting settings

## Documentation

Comprehensive documentation is available in the `docs/` directory:

- [Architecture Overview](docs/architecture/system-overview.md)
- [Deployment Guide](docs/operations/deployment-guide.md)
- [API Specifications](docs/specifications/orchestration-api.md)
- [Development Setup](docs/development/setup-guide.md)

## Development

### Setting Up Development Environment

```bash
# Install development dependencies
make install-dev

# Run code formatting
make format

# Run linting
make lint

# Run type checking
make type-check

# Run all checks
make check
```

### Running Tests

```bash
# Run all tests
make test

# Run unit tests only
make test-unit

# Run integration tests
make test-integration
```

### Contributing

Please see [CONTRIBUTING.md](docs/development/contribution-guide.md) for guidelines on contributing to DEAN Orchestration.

## Project Structure

```
DEAN/
├── src/                    # Source code
│   ├── orchestration/      # Core orchestration logic
│   ├── interfaces/         # CLI and web interfaces
│   └── integration/        # Service client implementations
├── tests/                  # Test suite
├── docs/                   # Documentation
├── configs/                # Configuration files
├── scripts/                # Operational scripts
└── examples/               # Usage examples
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support and questions:
- Check the [documentation](docs/)
- Review [examples](examples/)
- Open an issue on GitHub

## Related Repositories

- [IndexAgent](https://github.com/dean-project/IndexAgent) - Code analysis and agent operations
- [airflow-hub](https://github.com/dean-project/airflow-hub) - Workflow orchestration
- [infra](https://github.com/dean-project/infra) - Infrastructure and deployment